package co.edu.Unbosque.Model;

import java.util.ArrayList;

public class Juego {

	private Jugador j1;

	private Jugador j2;

	private boolean adivino;

	private String[] palabras = {"HARRY POTTER", "CORANOVIRUS","ESPARATRAPO", "BETTY LA FEA" , "ESTERNOCLEIDOMASTOIDEO", "INSTITUCIONALIZACION", 
			"PROGRAMACION",	"PARANGARICUTIRIM�CUARO","VENTRILOCUO","ESTRUCTURAS DE DATOS", "OTORRINOLARINGOLOGO", 
			"PARALELEPIPEDO", "WALT DISNEY WORLD","INGENIERIA DE SISTEMAS", "MICROPROCESADOR", "REPUBLICA DE COLOMBIA", 
			"RAPIDOS Y FURIOSOS", "ELECTROCARDIOGRAMA", "BAD BUNNY","IDIOSINCRACIA", "PANTORRILLA", "BILLIE ELLISH", 
			"SHREK", "PASION DE GAVILANES" };

	private char[] palabraElegida;

	private ArrayList<Character> palabraAdivinando;

	public Juego() {

		j1 = new Jugador();

		j2 = new Jugador();

		j1.setTurno(true);

		j2.setTurno(false);

		palabraElegida = palabraAleatoria().toCharArray();

		setAdivino(false);

		palabraAdivinando = new ArrayList<Character>();

	}

	public String palabraAleatoria() {

		int aleatorio =(int)(Math.random()*24);

		return palabras[aleatorio];

	}

	public void cambiarTurno() {

		if (j1.isTurno() == false && j2.isTurno() == true) {			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (j2.isHizoJugada()==false) {
				j2.setPuntos(j2.getPuntos()-1);
			}
			j1.setTurno(true);
			j2.setTurno(false);
		}

		if (j2.isTurno() == false && j1.isTurno() == true) {			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (j1.isHizoJugada()==false) {
				j1.setPuntos(j1.getPuntos()-1);
			}
			j2.setTurno(true);
			j1.setTurno(false);
		}
	}

	public char adivinarLetra(char ingreso) {

		for (int i = 0; i < palabraElegida.length; i++) {
			for (int j = 0; j < palabraAdivinando.size(); j++) {
				if(palabraAdivinando.get(j) != ingreso) {
					if (ingreso == palabraElegida[i] && palabraElegida[i] != ' ') {
						setAdivino(true);
						return ingreso;
					}
					while (adivino) {
						if (ingreso == palabraElegida[i]) {
							palabraAdivinando.add(i, ingreso);
						}
					}
				}
			}
		}
		return ingreso;

	}

	public boolean adivinarPalabra(String entrada) throws InterruptedException {

		boolean igual =false;
		if (cincuenta()) {
			if (j1.isTurno()) {
				char[] ent = entrada.toString().toCharArray();
				if (ent.equals(palabraAdivinando)) {
					igual = true;
					j1.setPuntos(j1.getPuntos()+1);
				} else {
					j1.setPuntos(j1.getPuntos()-1);
				}
				Thread.sleep(5000);
				cambiarTurno();
			} 
			if (j2.isTurno()) {
				char[] ent = entrada.toString().toCharArray();
				if (ent.equals(palabraAdivinando)) {
					igual = true;
					j2.setPuntos(j2.getPuntos()+1);
				}else {
					j2.setPuntos(j2.getPuntos()-1);
				}
				Thread.sleep(5000);
				cambiarTurno();
			}
			
		}
		
		return igual;

	}

	public boolean cincuenta() {

		int sinEspacios = 0;
		for (int i = 0; i < palabraElegida.length; i++) {
			if (palabraElegida[i] == ' ') {
				sinEspacios++;					
			}
		}
		if (palabraAdivinando.size() >= ((palabraElegida.length-sinEspacios)/2)) {
			return true;
		}

		return false;
	}
	
	public void ganar() {
		if (j2.getPuntos()==0) {
			j1.setGano(true);
		}
		if (j1.getPuntos() == 0) {
			j2.setGano(true);
		}
	}



	public Jugador getJ1() {
		return j1;
	}

	public void setJ1(Jugador j1) {
		this.j1 = j1;
	}

	public Jugador getJ2() {
		return j2;
	}

	public void setJ2(Jugador j2) {
		this.j2 = j2;
	}

	public boolean isAdivino() {
		return adivino;
	}

	public void setAdivino(boolean adivino) {
		this.adivino = adivino;
	}

	public String[] getPalabras() {
		return palabras;
	}

	public void setPalabras(String[] palabras) {
		this.palabras = palabras;
	}

	public char[] getPalabraElegida() {
		return palabraElegida;
	}

	public void setPalabraElegida(char[] palabraElegida) {
		this.palabraElegida = palabraElegida;
	}





}
