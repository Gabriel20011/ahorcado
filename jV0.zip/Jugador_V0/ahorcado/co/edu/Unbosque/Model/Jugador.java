package co.edu.Unbosque.Model;

public class Jugador {
	
	private int puntos;
	
	private boolean turno;
	
	private boolean hizoJugada;
	
	private boolean gano;
	
	public Jugador() {
		
		setPuntos(10);
	
		setTurno(false);
		
		setHizoJugada(false);
		
		setGano(false);
		
	}

	public int getPuntos() {
		return puntos;
	}

	public void setPuntos(int puntos) {
		this.puntos = puntos;
	}

	public boolean isTurno() {
		return turno;
	}

	public void setTurno(boolean turno) {
		this.turno = turno;
	}

	public boolean isHizoJugada() {
		return hizoJugada;
	}

	public void setHizoJugada(boolean hizoJugada) {
		this.hizoJugada = hizoJugada;
	}

	public boolean isGano() {
		return gano;
	}

	public void setGano(boolean gano) {
		this.gano = gano;
	}


}
